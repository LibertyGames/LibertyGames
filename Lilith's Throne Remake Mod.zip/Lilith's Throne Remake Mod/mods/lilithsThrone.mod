Replace:
    <!-- Modules -->
With:
    <!-- Modules -->
    <script type="module" src="mods/lilithsThrone.js"></script>
    
Replace:
        /* Load Game */
        loadGame();
With:
        /* Load Game
        loadGame(); */