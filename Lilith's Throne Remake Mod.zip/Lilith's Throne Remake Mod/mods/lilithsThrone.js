// Test
console.log("Lilith's Throne Mod loaded!")

// Load all Locations
loadScript('mods/lilithsThroneLocations.js', () => {
    console.log('lilithsThroneLocations.js loaded!');
    // You can now call functions defined in lilithsThrone.js
    grid.locations = parseLocations(lilithsThroneLocations).locations;
});

// Load all Grids
loadScript('mods/lilithsThroneGrids.js', () => {
    console.log('lilithsThroneGrids.js loaded!');
    // You can now call functions defined in lilithsThrone.js
    window.allGrids = { ...selectionGrid, ...lilithsThroneGrids };
});

// Load all Items
loadScript('mods/lilithsThroneItems.js', () => {
    console.log('lilithsThroneItems.js loaded!');
    // You can now call functions defined in lilithsThrone.js
    window.allItems = { ...lilithsThroneItems, ...window.allItems };
});

// Load all Moves
loadScript('mods/lilithsThroneMoves.js', () => {
    console.log('lilithsThroneMoves.js loaded!');
    // You can now call functions defined in lilithsThrone.js
    window.allMoves = { ...lilithsThroneMoves, ...window.allMoves };
});

// Change the Title
document.title = "Lilith's Throne";

// Change Start Background
displayBackgroundImage("None", "#2A2A2A");

// Change Game Logo
function displayGameLogo(img) {
    // Select the logo element
    const logo = document.querySelector('.logo');

    // Set the new image using template literal
    logo.style.backgroundImage = `url('res/mods/lilithsthrone/${img}')`;

    // Optional: make sure it displays nicely
    logo.style.backgroundSize = "contain"; // or "cover" if you want it to fill
    logo.style.backgroundRepeat = "no-repeat";
    logo.style.backgroundPosition = "center";
}

window.passages.WelcomeHeaderLT = () => `
    <div class="controls">
        <button id="open-left" aria-controls="leftSidebar">Open Left</button>
    </div>
    <div class="brand">
        <div class="logo"></div>
        <div>
            <div class="title">Lilith's Throne Remake</div>
            <div class="subtitle">A remake mod of the popular Lilith's Throne game.</div>
        </div>
    </div>
    <div class="controls">
        <button id="open-right" aria-controls="rightSidebar">Open Right</button>
        <div class="toggle" title="Toggle theme">
            <div id="themeToggle" class="switch" role="switch" aria-checked="false" tabindex="0">
                <div class="knob"></div>
            </div>
        </div>
    </div>
`;

window.passages.WelcomeMainLT = () => ` 
    <section class="card">
        <h2>Welcome to Lilith's Throne Remake</h2>
        <p>This game is a text-based erotic RPG, and contains a lot of graphic sexual content.​.</p>
        <p>Click the button below to start the game.</p>
        <div style="margin-top:16px;display:flex;gap:12px;flex-wrap:wrap">
            <button id="startilithsThroneRemake" onclick="startilithsThroneRemake()">Start Game</button>
        </div>
    </section>
`;

window.passages.WelcomeLeftLT = () => `
    <header><strong>Lilith's Throne Remake</strong><button id="close-left">Close</button></header>
    <br><br><br><br>
    <div class="button-group">
      <button id="loc-editor" onClick="openLocationEditor()">Location Editor</button>
      <button id="options" onClick="openOptions()">Options</button>
      <button id="saves" onClick="openSaves()">Saves</button>
      <button id="dialogue-tool" onClick="openDialogueTool()">Dialogue Tool</button>
      <button id="inventory" onClick="openInventory()">Inventory</button>
      <button id="quests" onClick="openQuests()">Quests</button>
      <button id="audio" onClick="openAudio()">Audio</button>
      <button id="leveling" onClick="openLeveling()">Leveling</button>
      <!-- <button id="combattesting" onClick="openCombatTesting()">Combat Testing</button> -->
      <!--  --><button id="establishmenttesting" onClick="openEstablishmentTesting()">Establishment Testing</button>
    </div>
    <style>
      #close-left {
        margin-right: 30px;
        max-width: 80px;
      }
    </style>
`;

window.passages.WelcomeRightLT = () => `
    <header><strong>Welcome to the Game</strong><button id="close-right">Close</button></header>
    <br><br><br><br>
    <!--
    <div class="item">Context panel 1</div>
    <div class="item">Context panel 2</div>
    <div class="item">Context panel 3</div>
    <div class="item">Recent activity and logs</div>
    -->
    <style>
      #close-right {
        margin-right: 30px;
      }
`;

// Load Lilith's Throne Game
function loadGame() {
    /* Spawn All People */
    // spawnAllPeople();
    // ensureUniqueNames(); // Ensure all names are unique

    // Display Main Menu
    showPassage('WelcomeHeaderLT', 'Header');
    showPassage('WelcomeMainLT', 'Main');
    showPassage('WelcomeLeftLT', 'Left');
    showPassage('WelcomeRightLT', 'Right');
    forceFitPage();

    // Display Logo
    displayGameLogo("Innoxia_inferior.webp");

    // Set Color Scheme
    setAccentColor('#9A0C84');

    // Player Family Initialization
    window.player = window.player || allNPCs.find(n => n.role === 'son'); // class Person Riverbend Lodge "Frostwillow Lodge"
    window.mother = allNPCs.find(n => n.role === 'mother');
    window.father = allNPCs.find(n => n.role === 'father');
    window.sibling = allNPCs.find(n => n.role === 'daughter');
    window.siblingRole = "Sister"; // enableClicks / if (person === player) renderInventory() case "Light": case "Dark":

    // Testing
    makePlayerOP();
}

function startilithsThroneRemake() {
    // alert('Sample action triggered');
    showPassage('NavViewer', 'Main'); // showPassage('Establishment', 'Main'); // GridNav
    showPassage('GridNav', 'Right');
    let startingGrid = "DominionGrid";
    loadGrid(startingGrid); // RiverbendLodgeGrid SunscaleVillageGrid WhisperingPinesGrid Whispering Pines
    // startDialogue(dialogues.LOAIntroTest); // dialogues.LOAIntro/dialogues.LOAPrologue / function startDialogue
    startAudio();
}

loadGame();