const lilithsThroneGrids = {
    "Select Grid": [],
    DominionGrid: [
        {
            x: 1, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 2, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 3, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 5, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 14, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 15, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 17, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 18, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 19, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 20, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 21, y: 0,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 1, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 3, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 5, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 7, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 15, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 17, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 19, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 21, y: 1,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 1, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 2, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 3, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 4, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 5, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 6, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 7, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 8, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 10, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 12, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 14, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 15, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 16, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 17, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 18, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 19, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 20, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 21, y: 2,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 3, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 14, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 17, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 21, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 22, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 23, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 24, y: 3,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 3, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 12, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 14, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 17, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 18, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 19, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 20, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 21, y: 4,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 5,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 10, y: 5,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 5,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 5,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 6,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 6,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 12, y: 6,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 6,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 7,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 7,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 7,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 9, y: 8,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 10, y: 8,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 8,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 12, y: 8,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 13, y: 8,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 9,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 10,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 11,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 12,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 13,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 14,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 15,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 16,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 17,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 18,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 19,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 20,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 21,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 22,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        },
        {
            x: 11, y: 23,
            location: {
                name: "Dominion Boulevard",
                type: "Boulevard",
                subtype: "Boulevard",
                description: "You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​",
                price: 300,
                color: "#95A5A6",
                image: "No image available",
                zoneType: "Area"
            },
            isStartingPoint: false,
            travelConfig: {}
        }
    ]
}