const lilithsThroneLocations = `
Location Hierarchies: 
Lilith's Domain
    Dominion
        Dominion Boulevard
        Dominion Streets
        Dominion Shaded Streets
        Dominion Alleyways
        Dominion Dark Alleyways
        Dominion Canals
        Dominion Exit North
        Dominion Exit South
        Dominion Exit East
        Dominion Exit West
        Dominion City Hall
        Lilith's Plaza
        Enforcer HQ
        Dominion Park
        Harpy Nests
        Argus's DIY Depot
        Red Light District
            Red Light District Streets
        Dominion Shopping Arcade
            Dominion Shopping Arcade Entrance
            Dominion Shopping Arcade Walkways
        Submission Entrance Northwest
        Submission Entrance Northeast
        Submission Entrance Southwest
        Submission Entrance Southeast
        Submission
            Submission Walkways
            Submission Tunnels

Location Info: 
Lilith's Domain
	Type: Region
	Subtype: Domain Region
	Description: Lilith’s Domain is a vast, alternate-timeline realm ruled by Lilith. Its capital, Dominion, is a bustling, dangerous city filled with intrigue, commerce, and supernatural activity. The domain spans mysterious lands, with hidden alleyways, underground passages, and regions inhabited by demons, cultists, and other creatures loyal to Lilith. Life in the domain is a mix of opportunity, danger, and power, where the influence of Lilith reaches every corner.
	Image: No image available
	ZoneType: Domain

Dominion
	Type: City
	Subtype: City
	Description: Dominion is the capital city of Lilith’s Domain and the starting location in Lilith’s Throne. Set in an alternate-timeline England reminiscent of Victorian London, Dominion is divided into four quadrants radiating from Lilith’s Plaza at the city center. \n\nThe city is lively and dangerous: main boulevards are safe and well-lit, but alleyways spawn muggers, prostitutes, and, deeper inside, demons that ambush visitors. Players can interact with NPCs, buy property, recruit guests or slaves, and explore both above and below the city. Beneath Dominion lies the subterranean city of Submission, accessible through scattered stairways. \n\nKey locations include Lilaya’s Home, the Dominion City Hall, shopping districts, the Nightlife district with bars and clubs, and Demonhome, an upscale demon neighborhood. Seasonal events, such as snow-clearing reindeer crews in winter or cultist activities in October, add life to the city. \n\nDominion sits roughly in the center of the Foloi Fields, with the River Hubur flowing through its streets and the tunnels below. The city is a mix of intrigue, commerce, and danger, forming the heart of Lilith’s Domain.
	Passage: AgeofHeroes
	Images: Timeline
	Image: No image available
	ZoneType: Region
    GameType: Modern

Dominion Boulevard
	Type: Boulevard
	Subtype: Boulevard
	Description: You find yourself walking down one of Dominion's main boulevards, which is at least twice the width of all the other streets that you've seen in the city.​ Large, immaculately-maintained residential and commercial buildings flank the road on each side; their white marble façades decorated with countless flags bearing the black pentagram of Lilith.​ 
	Image: No image available
	ZoneType: Area

Dominion Streets
    Type: Streets
    Subtype: Streets
    Description: Although the streets of Dominion look similar to those of Victorian-era London, there's a strange feel to them that hints at the other-worldly nature of this place.​ Instead of cars and trucks, the paved roads are home to wooden carts being pulled by either horses or centaur slaves.​ Rows of trees and marble benches line either side of the pedestrianised streets, offering shade and a place to rest for weary shoppers.​ On either side of you, the building's clean façades gleam in the sunshine, and high above in the sky, you see harpies flying about on business of their own.​​ \n\nThe streets are very busy at this time of day, and are packed with people hurrying to and fro.​ Despite their alarming appearances, the citizens of Dominion appear to be completely normal in every other way.​ You see those people who are always in a rush to be somewhere else, the crowds of shoppers lazily ambling by, the groups of friends laughing and chatting on benches, and all the other sorts that you'd find in any old city.​ As the streets are so busy at this time, you find yourself having to occasionally push your way through the dense crowds.​​ \n\nMost of the people around you are partial or lesser morphs, although there are a quite a few greater morphs to be seen walking the streets as well.​ Dog, cat and horse-morphs are by far the most common races that you see, but it wouldn't take long to find examples of every race.​ The rarest races that you see are humans and demons.​ The latter are very easy to spot, as wherever they walk, people hurriedly move to make way.
	Image: No image available
	ZoneType: Area

Dominion Shaded Streets
    Type: Streets
    Subtype: Shaded Streets
    Description: Although the streets of Dominion look similar to those of Victorian-era London, there's a strange feel to them that hints at the other-worldly nature of this place.​ Instead of cars and trucks, the paved roads are home to wooden carts being pulled by either horses or centaur slaves.​ Rows of trees and marble benches line either side of the pedestrianised streets, offering shade and a place to rest for weary shoppers.​ On either side of you, the building's clean façades gleam in the sunshine, and high above in the sky, you see harpies flying about on business of their own.​ \n\nThe streets are very busy at this time of day, and are packed with people hurrying to and fro.​ Despite their alarming appearances, the citizens of Dominion appear to be completely normal in every other way.​ You see those people who are always in a rush to be somewhere else, the crowds of shoppers lazily ambling by, the groups of friends laughing and chatting on benches, and all the other sorts that you'd find in any old city.​ As the streets are so busy at this time, you find yourself having to occasionally push your way through the dense crowds.​ \n\nMost of the people around you are partial or lesser morphs, although there are a quite a few greater morphs to be seen walking the streets as well.​ Dog, cat and horse-morphs are by far the most common races that you see, but it wouldn't take long to find examples of every race.​ The rarest races that you see are humans and demons.​ The latter are very easy to spot, as wherever they walk, people hurriedly move to make way.​
	Image: No image available
	ZoneType: Area

Dominion Alleyways
    Type: Alleyways
    Subtype: AlleyWays
    Description: You find yourself walking through labyrinthine alleyways, with not a soul in sight.​ Back-doors and steaming vents line the dark brick walls, and you often have to navigate around overflowing bins and stacks of empty crates in order to make progress.​ \n\nDue to the abundance of hiding places from which an ambush could be sprung, you recognise this as being a dangerous area, and you realise that you could be attacked at any moment…
	Image: No image available
	ZoneType: Area
    
Dominion Dark Alleyways
    Type: Alleyways
    Subtype: Dark Alleyways
    Description: You find yourself walking through labyrinthine alleyways, with not a soul in sight.​ Back-doors and steaming vents line the dark brick walls, and you often have to navigate around overflowing bins and stacks of empty crates in order to make progress.​ \n\nDue to the abundance of hiding places from which an ambush could be sprung, as well as your significant distance from any of Dominion's main streets, you recognise this as being a very dangerous area, and you realise that you could be attacked at any moment…
	Image: No image available
	ZoneType: Area

Dominion Exit North
	Type: Boulevard
	Subtype: Boulevard
	Description: A pair of elite demon Enforcers are keeping a close watch on everyone who enters or leaves the city.​ Although there's nothing stopping you from heading out into the world beyond, you have no reason to leave Dominion at the moment, and, without a map, you imagine that it would be quite easy to get lost.​ \n\nYour quest to find out how to return to your old world will no doubt eventually lead you to places other than Dominion, but for now, your business is within the city itself.​
	Image: No image available
	ZoneType: Area

Dominion Exit South
	Type: Boulevard
	Subtype: Boulevard
	Description: A pair of elite demon Enforcers are keeping a close watch on everyone who enters or leaves the city.​ Although there's nothing stopping you from heading out into the world beyond, you have no reason to leave Dominion at the moment, and, without a map, you imagine that it would be quite easy to get lost.​ \n\nYour quest to find out how to return to your old world will no doubt eventually lead you to places other than Dominion, but for now, your business is within the city itself.​
	Image: No image available
	ZoneType: Area

Dominion Exit East
	Type: Boulevard
	Subtype: Boulevard
	Description: A pair of elite demon Enforcers are keeping a close watch on everyone who enters or leaves the city.​ Although there's nothing stopping you from heading out into the world beyond, you have no reason to leave Dominion at the moment, and, without a map, you imagine that it would be quite easy to get lost.​ \n\nYour quest to find out how to return to your old world will no doubt eventually lead you to places other than Dominion, but for now, your business is within the city itself.​
	Image: No image available
	ZoneType: Area

Dominion Exit West
	Type: Boulevard
	Subtype: Boulevard
	Description: A pair of elite demon Enforcers are keeping a close watch on everyone who enters or leaves the city.​ Although there's nothing stopping you from heading out into the world beyond, you have no reason to leave Dominion at the moment, and, without a map, you imagine that it would be quite easy to get lost.​ \n\nYour quest to find out how to return to your old world will no doubt eventually lead you to places other than Dominion, but for now, your business is within the city itself.​
	Image: No image available
	ZoneType: Area

Dominion City Hall
    Type: City Hall
    Subtype: City Hall
    Description: This particular street is dominated by the huge structure of Dominion's city hall.​ The architecture of this seat of local government is distinctly classical, with the frontage consisting of a series of huge marble pillars and polished stone steps.​ A sign near the entrance of this impressive building informs you that it's open to the public from 9:00 AM-4:00 PM.​
	Image: No image available
	ZoneType: Area

Lilith's Plaza
    Type: Plaza
    Subtype: City Plaza
    Description: You find yourself standing in the very centre of Dominion, where an expansive public square is situated.​ Large residential and commercial buildings flank the plaza on each of its four sides.​ Looking around, you see that each and every one of their white marble façades are decorated with dark-purple flags bearing the black pentagram of Lilith.​ Numerous grandiose statues and extravagantly-detailed water fountains, all carved from polished white marble, are scattered about throughout this large area.​ Each one of these sculptures appears to represent a demon or Lilin, and although they're each a marvellous work of art, the one in the very middle of the square is quite simply breathtaking.​ \n\nOn top of a plinth of at least one hundred feet in height, there stands a gigantic marble statue of Lilith herself; with wings fully unfurled, and with her hands resting on her wide hips, she smirks down with a visage of manic delight at the crowds below.​ Although she no doubt possesses the power to transform into almost any form imaginable, this statue represents her as a cliché, stereotypical succubus, albeit an exceptionally beautiful one.​ Wearing only the scantiest of sexy, form-fitting lingerie, every inch of Lilith's curvaceous body is on display for all to see, and you find yourself looking straight up at Lilith's tight pussy as the thin fabric of her thong rides up between her tiny labia.​ \n\nBeing the central meeting place for Dominion's citizens, this plaza is the busiest location in all of Dominion.​ Throngs of people, of all different races and appearances, fill the square.​ Some appear to be simply passing through the area, while others lounge about on the many wooden benches and marble steps at the base of each statue.​ \n\nOn raised platforms, well-spoken orators address the crowds, relaying news and important announcements to the many citizens who pass by.​ Pamphlets and newspapers are handed out beside each one of these stands, and you realise that this is the only place where you've seen any form of news being distributed to the population.
	Image: No image available
	ZoneType: Area

Enforcer HQ
    Type: Police Station
    Subtype: Police Station
    Description: Being built in an extremely imposing example of brutalist architecture, the vast structure before you is strikingly different from the usual residential buildings which Dominion is mostly comprised of.​ A wide courtyard, paved in drab, grey flagstones and cordoned off with chain bollards, separates the street on which you're standing from this unusual property.​ Looking up at the façade, which is made almost entirely out of sheets of reflective glass and thick pillars of grey concrete, you see that there's a sign bearing the words 'Enforcer Headquarters, Greyhaven Park'. ​\n\nAs if the sign wasn't enough to reveal this establishment's purpose to any passersby, there are also numerous groups of smartly-dressed demon Enforcers loitering about the courtyard, with several more standing guard at each of the three main entrances.​ While the signs beside two of these doorways inform you that they're for Enforcer use only, the third bears the words 'Public Inquiries; Reception open 9:00 AM-5:00 PM'.
	Image: No image available
	ZoneType: Building

Dominion Park
    Type: Park
    Subtype: Park
    Description: This area of Dominion is taken up by a gigantic park, filled with a lush amount of foliage, which makes the air here feel very fresh compared to the rest of the city.​ The park consists of several alternating areas of open lawn and woodland, connected by a series of winding paths.​ There's a small lake situated in one corner of the park, and adjacent to that, there's a small field of wild flowers.​ A couple of food stands have been set up in one area for people that didn't come prepared with a picnic.​ ​\n\nThe most noteworthy feature is at the very centre of the park, and takes the form of a huge statue of Lilith herself.​ The sultry smile carved into the white marble almost feels at though it's mocking you, and you can't help but feel as though you don't want to stick around here for long.​ ​\n\nFor now, you don't have much reason to wander through this park, but if you had someone else with you, it would be a nice place to spend an afternoon; if you can ignore the statue, that is…
	Image: No image available
	ZoneType: Area  

Harpy Nests
    Type: Harpy Nest
    Subtype: Harpy Nest
    Description: An arrow-shaped sign sits in the middle of the street, and as you approach, you see that it's sporting the words 'Harpy Nests'.​ Looking to the side of the road in the direction that the arrow is pointing, you find yourself looking up at one of the tallest buildings in Dominion.​ \n\nAt eight stories in height, it's not exactly a sky-scraper, but with most of Dominion's buildings typically only being four or five stories tall at most, this structure is large enough to clearly stand out as a building of some importance.​ Despite its unusual height, the only other feature setting it apart from all the other buildings in this area are the pair of huge glass doors set into its frontage.​​ \n\nLooking through the doors, you see a brightly-lit, extravagantly-decorated lobby.​ Rows of elevators are set into either side of the room, and you notice that there are an unusual amount of harpies loitering around on the many comfortable-looking sofas that litter the area.​​ \n\nIt's obvious from even a cursory glance that this building is the entrance to the rooftop Harpy Nests, and you wonder if you should step inside and make use of one of the elevators.​
	Image: No image available
	ZoneType: Area  

Argus's DIY Depot
    Type: Supermarket
    Subtype: Supermarket Warehouse
    Description: Set back from one of the main streets, and with Dominion's canal running close behind it, there's an expansive lumber yard, with a couple of large warehouses sitting in the middle of it.​ An impressive wrought-iron sign over the entrance to this area declares it be 'Argus's DIY Depot', while smaller, wooden signs attached to the supporting posts reveal that the warehouses are open from 6:00 AM-10:00 PM.​ \n\nLooking across at the warehouses, you see that one is quite clearly signposted as being open to the general public, while the other is apparently just for supplying small businesses.​ Huge posters advertising cans of paint, ceramic tiles, tools, timber, and all manner of miscellaneous building supplies have been plastered all over the walls of these warehouses, letting passersby know the sort of things which can be purchased here.​​ \n\nAs the warehouses are currently open, you could always head inside the one signposted as being open to the public and do some shopping for DIY or building supplies.
	Image: No image available
	ZoneType: Area  

Red Light District
    Type: District
    Subtype: District
    Description: Although prostitutes and brothels can be found all throughout Dominion, the area that you find yourself in is dedicated entirely to the sex industry.​ Every building that you pass seems to be a brothel; their large glass windows, illuminated with red lights, being used to display men and women of all races, who dance and wink at passersby in an attempt to lure them into their establishment.​ Neon lights, which you suspect to be arcane-enchanted, shine out in many different colours all around you, either bearing the name of the brothel that they're affixed to, or displaying some kind of generic slogan.​ \n\nThe city's prostitutes aren't limited to the confines of these brothels, and as you walk through the area, you pass countless scantily clad girls, who wink at you and call out their prices for oral, anal, and vaginal sex.​ Just like all of the other streets in Dominion, this one is very busy, and, looking around, you see numerous members of the surrounding crowds heading into one brothel or another, or handing over money to one of the street prostitutes before ducking off with them down a nearby alleyway.​
	Image: No image available
	ZoneType: Area  

Red Light District Streets
    Type: District 
    Subtype: District
    Description: The streets of the Red Light District are bustling and crowded, full of passersby heading to various brothels or stopping to pay street prostitutes. Every alley and walkway is busy, with numerous girls of all races calling out their services and prices for oral, anal, and vaginal sex. Neon lights, many of which appear to be arcane-enchanted, shine from the brothels and signage along the streets, creating a colorful and lively atmosphere. The district is dedicated entirely to the sex industry, and the crowds moving through the streets reflect the constant activity of Dominion’s adult entertainment scene.
	Image: No image available
	ZoneType: Area  

Dominion Shopping Arcade
    Type: Mall
    Subtype: District
    Description: The streets in this part of Dominion seem to be busier than usual, and you notice that many of the people surrounding you are holding shopping bags of all shapes and sizes.​ The cause of this unusual increase in traffic is soon made apparent, as up ahead you see a huge shopping centre, with yet more people loitering around the ornate entranceway.​​ \n\nAs you approach, you take a good look at the massive building, noting that its style is very reminiscent of that of a grand Victorian shopping arcade.​ From what you can see through the entrance's glass doors, it looks as though the shops inside are all open for business.​ Sure enough, taking a look over to one side of the entrance, you notice a sign proclaiming that most shops within the arcade are open from 6:00 AM-10:00 PM.​ \n\nYou wonder if you should take this opportunity to go and do some shopping…
	Image: No image available
	ZoneType: Building  

Dominion Shopping Arcade Entrance
    Type: Mall
    Subtype: District
    Description: You find yourself standing in the entrance to the shopping arcade.​ A wide, marble-floored walkway stretches out before you, and on either side, huge glass windows proudly display a wide variety of different goods for sale.​ Looking up to the two-story-high ceiling, you see that the entire arcade is enclosed by a long, glass archway, offering protection not only from the wind and rain, but also shielding anyone below from the effects of an arcane storm.​​​ \n\nBusy crowds of shoppers jostle amongst each other as they travel between the many shops found within the arcade.​ Their chatter reverberates off the windows and walls on either side to create a loud, energetic atmosphere all around you.​​​ \n\nThere are several touristy-looking information boards placed nearby, and, after consulting one, you feel confident that you could easily find your way to any of the more interesting stores.​
	Image: No image available
	ZoneType: Room  

Dominion Shopping Arcade Walkways
    Type: Mall
    Subtype: District
    Description: You walk down the wide, marble-floored walkway which loops around and through the shopping arcade.​ On either side of you, huge glass windows proudly display a wide variety of different goods for sale.​ Glancing up at the two-story-high ceiling, you see that the entire arcade is enclosed by a long, glass archway, offering protection not only from the wind and rain, but also shielding anyone below from the effects of an arcane storm.​ \n\nBusy throngs of the arcade's patrons jostle to and fro, and you often find yourself having to push your way through idling crowds that inexplicably gather right in the middle of your path.​ Their chatter reverberates off the windows and walls on either side of you to create a loud, energetic atmosphere all the way through the arcade.​
	Image: No image available
	ZoneType: Room  

Dominion Canals
    Type: Alleyways
    Subtype Canal Alleyways
    Description: You find yourself travelling down the narrow dirt path which runs alongside the entire length of Dominion's extensive canal network.​ While the track occasionally widens out or runs past small clearings and gardens, it is for the most part closely flanked by dark, red-bricked buildings.​ Despite the fact that these high walls create a gloomy, oppressive atmosphere, you find yourself preferring to be in their presence rather than that of the more spacious, foliage-filled areas, as their leafy bushes, wooden fences, and waist-high walls provide ample hiding places from which muggers could launch an ambush. ​\n\nUnlike the city's back-alleys, this canal-side path is not completely deserted, as every now and then you come across a harmless citizen, who invariably averts their gaze as they hurry past you.​ The wide waterway itself is also extremely busy, with a seemingly never-ending procession of barges slowly trawling past on their way to destinations unknown.​ While several of them seem to be for recreational purposes, the vast majority of these narrow boats are hauling cargo of one sort or another; their long decks are stacked high with crates, packed with industrial machinery, or filled with tarpaulin-covered mounds of raw materials.​ ​\n\nDespite the high level of traffic on the canal itself, you get the feeling that nobody would come to your aid if you were to be attacked while travelling on this path.​ The distinct lack of any Enforcer presence is a clear indication that this dangerous area is ripe territory for muggers, and so you make sure to stay alert as you continue on your way…

Submission
    Type: Undercity
    Subtype: Undercity
    Description: Submission is the subterranean city beneath Dominion, accessible via stairs scattered throughout the capital. Its main tunnels are spacious, clean, and full of life, with a deep greenish water channel running through the center of each passage and well-maintained wooden walkways along the walls. Bridges cross the water at regular intervals, and stone steps provide access to the river below for aquatic inhabitants. \n\nThe air is damp but ventilated through wide iron grates in the ceiling, letting in light from above. Pipes and valves run along the upper walls, and houses and shops have been tunnelled into the stone. While less busy than Dominion, the tunnels are populated by slimes, alligator-morphs, rat-morphs, and other regular morphs. Enforcers patrol the passages frequently, maintaining order, while imps are rarely seen here, banished to darker side tunnels.
	Image: No image available
	ZoneType: Area 

Submission Walkways
    Type: Undercity
    Subtype: Undercity
    Description: The main tunnels of Submission are surprisingly spacious, clean and full of life.​ A deep channel of opaque, greenish water flows at a steady pace down the centre of each passage, and to either side, well-maintained wooden walkways have been built up against the grey stone walls.​ Numerous bridges cross the watery divide at regular intervals, and every three hundred and thirty feet or so, a series of stone steps trails down into the murky river to provide easy access for Submission's aquatic inhabitants.​ \n\nThe damp atmosphere holds just enough chill to gently caress any exposed skin, but, thanks to the wide iron grates built into the ceiling, the air doesn't feel stagnant down here.​ Looking up through the iron bars, you're granted an unobstructed view of the sky, and, every now and then, up the occasional skirt.​ The dizzying network of pipes and valves that run along the upper-half of the walls makes you feel sorry for whoever has to map and maintain them.​​ \n\nHouses and shops of all kinds have been tunnelled out and built into the walls, and, while not as busy as Dominion, there are enough people ambling by to fill the tunnels with a continuous background drone of chatter and laughter.​ There seems to be a heavy presence of Enforcers down here, and you can't go more than five minutes without seeing a patrol marching by.​​ \n\nDespite Submission being their home, you only see the occasional imp in this area; evidence that they're so much of a nuisance that the vast majority of them are banished to the dark tunnels that branch off on either side of this main passage.​ The vast majority of people that you pass are slimes, alligator-morphs, and rat-morphs, but there are also plenty of regular morphs eking out a living down here.​
	Image: No image available
	ZoneType: Area 

Submission Tunnels
    Type: Undercity
    Subtype: Unlike the main passages of Submission, the shaded alcoves and wide pipe openings make these dark, claustrophobic tunnels the perfect place for an ambush.​ Filmy perspiration drips from the walls, and you flinch every time a drop touches you.​ \n\nKicking up rubbish and random debris as you quickly move through the dilapidated area, each of your steps sounds as loud as a thunder-clap to your ears.​ You can't help but shake the feeling that someone's lying in wait around each corner, waiting for their chance to lunge out of the shadows and attack…
	Image: No image available
	ZoneType: Area 

Submission Entrance Northwest
    Type: Undercity
    Subtype: Undercity
    Description: A large stone bridge has been built over Dominion's canal, and as you walk over it, you hear the unmistakable sound of rushing water coming from below.​ Peering over the side, you see the origin of the noise; a huge, brick-lined opening, covered in metal bars, has been dug out on one side of the waterway, and it's into this that the water from the canal is flowing.​ Looking closer, you see that on the other side of the bars, there's a wide set of stone steps leading down into the gloom below.​​ ​\n\nSearching for a way to get access to those steps, and the area beyond, you soon find yourself standing before a building marked as 'Submission Enforcer Post'.​ The doors are wide open, and, peering inside, you see that the origin of the stone staircase is situated in the middle of a large, mostly-empty waiting room.​​ ​\n\nThere only appears to be one Enforcer guarding the staircase, who half-heartedly glances up from their newspaper as they catch sight of you.​ Letting out a sigh, they motion towards the staircase, clearly gesturing that you're able to come and go as you please.​
	Image: No image available
	ZoneType: Area

Submission Entrance Northeast
    Type: Undercity
    Subtype: Undercity
    Description: A large stone bridge has been built over Dominion's canal, and as you walk over it, you hear the unmistakable sound of rushing water coming from below.​ Peering over the side, you see the origin of the noise; a huge, brick-lined opening, covered in metal bars, has been dug out on one side of the waterway, and it's into this that the water from the canal is flowing.​ Looking closer, you see that on the other side of the bars, there's a wide set of stone steps leading down into the gloom below.​​ ​\n\nSearching for a way to get access to those steps, and the area beyond, you soon find yourself standing before a building marked as 'Submission Enforcer Post'.​ The doors are wide open, and, peering inside, you see that the origin of the stone staircase is situated in the middle of a large, mostly-empty waiting room.​​ ​\n\nThere only appears to be one Enforcer guarding the staircase, who half-heartedly glances up from their newspaper as they catch sight of you.​ Letting out a sigh, they motion towards the staircase, clearly gesturing that you're able to come and go as you please.​
	Image: No image available
	ZoneType: Area

Submission Entrance Southwest
    Type: Undercity
    Subtype: Undercity
    Description: A large stone bridge has been built over Dominion's canal, and as you walk over it, you hear the unmistakable sound of rushing water coming from below.​ Peering over the side, you see the origin of the noise; a huge, brick-lined opening, covered in metal bars, has been dug out on one side of the waterway, and it's into this that the water from the canal is flowing.​ Looking closer, you see that on the other side of the bars, there's a wide set of stone steps leading down into the gloom below.​​ ​\n\nSearching for a way to get access to those steps, and the area beyond, you soon find yourself standing before a building marked as 'Submission Enforcer Post'.​ The doors are wide open, and, peering inside, you see that the origin of the stone staircase is situated in the middle of a large, mostly-empty waiting room.​​ ​\n\nThere only appears to be one Enforcer guarding the staircase, who half-heartedly glances up from their newspaper as they catch sight of you.​ Letting out a sigh, they motion towards the staircase, clearly gesturing that you're able to come and go as you please.​
	Image: No image available
	ZoneType: Area

Submission Entrance Southeast
    Type: Undercity
    Subtype: Undercity
    Description: A large stone bridge has been built over Dominion's canal, and as you walk over it, you hear the unmistakable sound of rushing water coming from below.​ Peering over the side, you see the origin of the noise; a huge, brick-lined opening, covered in metal bars, has been dug out on one side of the waterway, and it's into this that the water from the canal is flowing.​ Looking closer, you see that on the other side of the bars, there's a wide set of stone steps leading down into the gloom below.​​ ​\n\nSearching for a way to get access to those steps, and the area beyond, you soon find yourself standing before a building marked as 'Submission Enforcer Post'.​ The doors are wide open, and, peering inside, you see that the origin of the stone staircase is situated in the middle of a large, mostly-empty waiting room.​​ ​\n\nThere only appears to be one Enforcer guarding the staircase, who half-heartedly glances up from their newspaper as they catch sight of you.​ Letting out a sigh, they motion towards the staircase, clearly gesturing that you're able to come and go as you please.​
	Image: No image available
	ZoneType: Area

Submission Enforcer Checkpoint Northeast 
    Type: Undercity
    Subtype: Undercity
    Description: A large stone building, spanning the entire width of the tunnel, has been erected here.​ A sign reading 'Official Enforcer Post' is clearly displayed beside the main entrance, and within, a dozen or so Enforcers are manning desks or standing guard beside internal doorways.​ None of them seem to pay you much attention, allowing you to come and go as you please.​ \n\nAs usual, you see the short, busty form of the cat-girl Enforcer, Claire, hurrying around as she fetches and delivers all sorts of miscellaneous paperwork.​ If you wanted to, you could approach her and ask for some more information about Submission.​​ \n\nJust a short distance from the Enforcer post's main entrance, there's a small alcove set into the tunnel's wall.​ Placed within this cavity there's a fully-functioning vending machine.​ Above the yellow machine's glass display, the words 'Hazmat Rat' have been written in bold, green letters, while on both of its sides there are stylised images of rat-morphs wearing hazmat suits.​
	Image: No image available
	ZoneType: Area

Submission Enforcer Checkpoint Northwest 
    Type: Undercity
    Subtype: Undercity
    Description: A large stone building, spanning the entire width of the tunnel, has been erected here.​ A sign reading 'Official Enforcer Post' is clearly displayed beside the main entrance, and within, a dozen or so Enforcers are manning desks or standing guard beside internal doorways.​ None of them seem to pay you much attention, allowing you to come and go as you please.​ \n\nAs usual, you see the short, busty form of the cat-girl Enforcer, Claire, hurrying around as she fetches and delivers all sorts of miscellaneous paperwork.​ If you wanted to, you could approach her and ask for some more information about Submission.​​ \n\nJust a short distance from the Enforcer post's main entrance, there's a small alcove set into the tunnel's wall.​ Placed within this cavity there's a fully-functioning vending machine.​ Above the yellow machine's glass display, the words 'Hazmat Rat' have been written in bold, green letters, while on both of its sides there are stylised images of rat-morphs wearing hazmat suits.​
	Image: No image available
	ZoneType: Area
    
Submission Enforcer Checkpoint Southeast 
    Type: Undercity
    Subtype: Undercity
    Description: A large stone building, spanning the entire width of the tunnel, has been erected here.​ A sign reading 'Official Enforcer Post' is clearly displayed beside the main entrance, and within, a dozen or so Enforcers are manning desks or standing guard beside internal doorways.​ None of them seem to pay you much attention, allowing you to come and go as you please.​ \n\nAs usual, you see the short, busty form of the cat-girl Enforcer, Claire, hurrying around as she fetches and delivers all sorts of miscellaneous paperwork.​ If you wanted to, you could approach her and ask for some more information about Submission.​​ \n\nJust a short distance from the Enforcer post's main entrance, there's a small alcove set into the tunnel's wall.​ Placed within this cavity there's a fully-functioning vending machine.​ Above the yellow machine's glass display, the words 'Hazmat Rat' have been written in bold, green letters, while on both of its sides there are stylised images of rat-morphs wearing hazmat suits.​
	Image: No image available
	ZoneType: Area
    
Submission Enforcer Checkpoint Southwest 
    Type: Undercity
    Subtype: Undercity
    Description: A large stone building, spanning the entire width of the tunnel, has been erected here.​ A sign reading 'Official Enforcer Post' is clearly displayed beside the main entrance, and within, a dozen or so Enforcers are manning desks or standing guard beside internal doorways.​ None of them seem to pay you much attention, allowing you to come and go as you please.​ \n\nAs usual, you see the short, busty form of the cat-girl Enforcer, Claire, hurrying around as she fetches and delivers all sorts of miscellaneous paperwork.​ If you wanted to, you could approach her and ask for some more information about Submission.​​ \n\nJust a short distance from the Enforcer post's main entrance, there's a small alcove set into the tunnel's wall.​ Placed within this cavity there's a fully-functioning vending machine.​ Above the yellow machine's glass display, the words 'Hazmat Rat' have been written in bold, green letters, while on both of its sides there are stylised images of rat-morphs wearing hazmat suits.​
	Image: No image available
	ZoneType: Area
`;